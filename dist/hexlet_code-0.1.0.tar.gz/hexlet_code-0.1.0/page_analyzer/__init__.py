from page_analyzer.app import app as app


__all__ = ('app',)
