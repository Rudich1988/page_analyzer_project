### Hexlet tests and linter status:
[![Actions Status](https://github.com/Rudich1988/python-project-83/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Rudich1988/python-project-83/actions)
[![Actions Status](https://github.com/Rudich1988/python-project-83/actions/workflows/pyci.yml/badge.svg)](https://github.com/Rudich1988/python-project-83/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/b573da64cfd884eb8d20/maintainability)](https://codeclimate.com/github/Rudich1988/python-project-83/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/b573da64cfd884eb8d20/test_coverage)](https://codeclimate.com/github/Rudich1988/python-project-83/test_coverage)

[Ссылка на домен](http://localhost:8000/)